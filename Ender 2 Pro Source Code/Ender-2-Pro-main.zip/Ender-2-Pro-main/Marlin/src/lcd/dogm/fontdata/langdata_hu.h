/**
 * Generated automatically by buildroot/share/fonts/uxggenpages.sh
 * Contents will be REPLACED by future processing!
 * Use genallfont.sh to generate font data for updated languages.
 */
#include <U8glib.h>

const u8g_fntpgm_uint8_t fontpage_2_241_241[31] U8G_FONT_SECTION("fontpage_2_241_241") = {
  0x00,0x0c,0x0f,0x00,0xfe,0x00,0x00,0x00,0x00,0x00,0xf1,0xf1,0x00,0x08,0x00,0x00,
  0x00,0x05,0x08,0x08,0x06,0x00,0x00,0x48,0x90,0x00,0x88,0x88,0x88,0x88,0x70};

#define FONTDATA_ITEM(page, begin, end, data) { page, begin, end, COUNT(data), data }
static const uxg_fontinfo_t g_fontinfo[] PROGMEM = {
    FONTDATA_ITEM(2, 241, 241, fontpage_2_241_241), // 'ű' -- 'ű'
};
